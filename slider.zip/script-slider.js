//Общие требования:
//Должна быть возможность пролистывать фото. Например, добавить 2 кнопки вперед и назад (предыдущее, следующее и так далее);
//При клике «назад» на первом фото должно открываться последнее. При клике «вперед» на последнем фото должно открываться первое;
//Блок, в котором располагаются изображения, не должен меняться под размер картинок;
//Добавить анимацию при переключении фото;
//На входе — массив изображений. Их может быть любое количество. Нельзя завязываться на порядковый номер элемента;
//Картинки можно положить в папку asset. Либо использовать стороннее API, сделав GET запрос для получения изображений;
//Соблюдать семантическую верстку;
//Использовать селекторы по тегу для задания стилей нельзя. Использовать классы. В случае, когда есть необходимость — селектор по id;
//Дизайн произвольный. Минимум — застилизовать кнопки (добавить hover) и обеспечить для них accessibility: переключение по tab, outline, cursor.

//Получаем количество картинок (Или количество дочерних элементов в div с идентификатором slides)
var count = document.getElementById('slides').childElementCount;
//Задаем ширину слайда в зависимости от количества картинок (1 картинка - 100%, 2 - 200% и тд)
var slides = document.getElementById("slides");
slides.style.width = 100 * count + "%";
// Создаем массив для левой кнопки
let arrPlus = [];
for (let i = 0; i < count; i++) {
    arrPlus[i] = i*100+"%";
}
arrPlus[0] = ""; //Изначально у слайда (slides) левая позиция пустая, это можно проверить с помощью console.log(slides.style.left);
// Создаем массив для правой кнопки
let arrMinus = [];
for (let i = 0; i < count; i++) {
    arrMinus[i] = i*(-100)+"%";
}
arrMinus[0] = "";
// Пишем функцию для кнопок
// Левая кнопка
function btnLeft(){
    if(slides.style.left === arrPlus[0]){ //При клике «назад» на первом фото открывается последнее;
        slides.style.left = arrMinus[arrMinus.length-1];
    }else {
        for (let i = 0; i < count; i++) {
            if(slides.style.left === arrPlus[i]){
                slides.style.left = arrPlus[i+1];
                break;
            }else if(slides.style.left === arrMinus[i]){
                slides.style.left = arrMinus[i-1];
                break;
            }
        }
    }
    //Обновляем таймер после каждого клика
    clearInterval(timer);
    timer = setInterval(btnRight,3000);
}
// Правая кнопка
function btnRight(){
    if(slides.style.left === arrMinus[arrMinus.length-1]){ //При клике «вперед» на последнем фото открывается первое;
        slides.style.left = arrPlus[0];
    }else {
        for (let i = 0; i < count; i++) {
            if(slides.style.left === arrMinus[i]){
                slides.style.left = arrMinus[i+1];
                break;
            }else if(slides.style.left === arrPlus[i]){
                slides.style.left = arrPlus[i-1];
                break;
            }
        }
    }
    //Обновляем таймер после каждого клика
    clearInterval(timer);
    timer = setInterval(btnRight,3000);
}

// Создаем таймер
var timer = setInterval(btnRight,3000);